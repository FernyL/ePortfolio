package com.zybooks.fernandolomeliinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

//SQLite database to hole item information
public class ItemsDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "itemInfo.db";
    private static final int VERSION = 1;
    public static final String TABLE_NAME = "items";
    private static final String COL_ID = "_id";
    public static final String COL_NAME = "name";
    public static final String COL_QUANTITY = "quantity";
    private Context context;

    public static final String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + "(" +
            COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_NAME + " text, " +
            COL_QUANTITY + " integer)";

    ItemsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_QUERY);
        db.execSQL("CREATE INDEX idx_title ON " + TABLE_NAME + " (" + COL_NAME + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + TABLE_NAME);
        onCreate(db);
    }

    //Function to add items to the database
    public void addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_QUANTITY, quantity);

        long itemId = db.insert(TABLE_NAME, null, values);
        if (itemId == -1) {
            Toast.makeText(context, "Failed to add item", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Item added", Toast.LENGTH_LONG).show();
        }
        db.close();
    }

    //Function to read data from database
    //public Cursor readData(){
    //    String query = "SELECT * FROM " + TABLE_NAME;
    //    SQLiteDatabase db = this.getReadableDatabase();
    //    Cursor cursor = null;
    //    if (db != null) {
    //        cursor = db.rawQuery(query, null);
    //    }
    //    return cursor;
    //}
    public Cursor readData(){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null,null, null, null, COL_NAME);
    }

    //Function to update data in the database
    void editData(String row_id, String name, String quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_QUANTITY, quantity);
        long result = db.update(TABLE_NAME, values, "_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Update failed", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Update successful", Toast.LENGTH_LONG).show();
        }
    }

    //function to delete an item from the database
    void deleteData(String row_id) {
        SQLiteDatabase db = this.getWritableDatabase();

        long result = db.delete(TABLE_NAME, "_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Deletion failed", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Item deleted", Toast.LENGTH_LONG).show();
        }
    }
}
