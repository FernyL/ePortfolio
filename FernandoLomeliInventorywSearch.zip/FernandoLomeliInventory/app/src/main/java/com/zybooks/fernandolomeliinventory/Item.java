package com.zybooks.fernandolomeliinventory;

public class Item {

    private int _id;
    private String name;
    private String quantity;

    public Item(int _id, String name, String quantity){
        this._id = _id;
        this.name = name;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public String getQuantity() {
        return quantity;
    }

    public int getId() {
        return _id;
    }
}
