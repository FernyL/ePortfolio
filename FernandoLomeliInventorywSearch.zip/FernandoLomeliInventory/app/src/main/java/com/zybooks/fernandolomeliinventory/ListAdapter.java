package com.zybooks.fernandolomeliinventory;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//Allows newly created items to be added to the inventory list
public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder>{

    //Initialize/declare fields
    Activity activity;
    private Context context;
    private Cursor cursor;

    private List<Item> itemList = new ArrayList<>();
    private List<Item> filteredList = new ArrayList<>();

    ItemsDatabase itemsDatabase;


    public ListAdapter(Activity activity, Context context, Cursor cursor) {
        this.activity = activity;
        this.context = context;
        this.cursor = cursor;
        setCursor(cursor);
    }

    public void setCursor(Cursor newCursor) {
        this.cursor = newCursor;
        itemList.clear();
        filteredList.clear();
        if(newCursor != null && newCursor.moveToFirst()) {
            do {
                int _id = newCursor.getInt(newCursor.getColumnIndexOrThrow("_id"));
                String name = newCursor.getString(newCursor.getColumnIndexOrThrow("name"));
                String quantity = newCursor.getString(newCursor.getColumnIndexOrThrow("quantity"));

                Item newItem = new Item(_id, name, quantity);
                itemList.add(newItem);
            } while (newCursor.moveToNext());
        }
        filteredList.addAll(itemList);
        notifyDataSetChanged();
    }

    public void filterItems(String query) {
        filteredList.clear();

        if (query.isEmpty()) {
            filteredList.addAll(itemList);
        }
        else {
            for (Item item : itemList) {
                boolean nameMatch = item.getName().toLowerCase().contains(query.toLowerCase().trim());

                if (nameMatch) {
                    filteredList.add(item);
                }
            }
        }

        new Handler(Looper.getMainLooper()).post(() -> notifyDataSetChanged());
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.custom_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListAdapter.ViewHolder holder, int position) {
        Item item = filteredList.get(position);

        holder.itemName_txt.setText(item.getName());
        holder.itemQuantity_txt.setText(item.getQuantity());

        //Send SMS notification if item count is 0
        String value = holder.itemQuantity_txt.getText().toString().trim();
        if (value.equals("0")) {
            InventoryActivity.SendSMSMessage(context.getApplicationContext());
        }

        holder.customList.setOnClickListener(view -> {
           Intent intent = new Intent (context, EditItemActivity.class);
            intent.putExtra("id", item.getId());
            intent.putExtra("Name", item.getName());
            intent.putExtra("Quantity", item.getQuantity());
           activity.startActivityForResult(intent, 1);
        });
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    public void swapCursor(Cursor newCursor) {
        if (cursor != null){
            cursor.close();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView itemID_txt, itemName_txt, itemQuantity_txt;
        LinearLayout customList;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemID_txt = itemView.findViewById(R.id.itemID);
            itemName_txt = itemView.findViewById(R.id.itemName);
            itemQuantity_txt = itemView.findViewById(R.id.itemQuantity);
            customList = itemView.findViewById(R.id.customList);
        }
    }
}
