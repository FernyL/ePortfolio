package com.zybooks.fernandolomeliinventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//This class allows the user to register or login to an account
public class LoginActivity extends AppCompatActivity {

    //Initialize/declare fields
    LoginDatabase loginDatabase;

    EditText emailAddress, editTextPassword;
    Button signinButton, registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        emailAddress = findViewById(R.id.emailAddress);
        editTextPassword = findViewById(R.id.editTextPassword);

        signinButton = findViewById(R.id.signinButton);
        registerButton = findViewById(R.id.registerButton);

        loginDatabase = new LoginDatabase(this);

        //Allows the user to register a new account to the database provided conditions are met
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email, password;
                email = emailAddress.getText().toString();
                password = editTextPassword.getText().toString();
                if (email.isEmpty() || password.length() < 6) {
                    Toast.makeText(LoginActivity.this, "Please fill all fields and ensure password is min 6 characters", Toast.LENGTH_LONG).show();
                } else {
                    if(loginDatabase.checkEmail(email)){
                        Toast.makeText(LoginActivity.this, "Email already exists", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Boolean success = loginDatabase.addUser(email, password);
                    if (success) {
                        Toast.makeText(LoginActivity.this, "Account created", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(LoginActivity.this, "Account creation failed", Toast.LENGTH_LONG).show();
                }
            }
        });

        //Allows the user to sign in to a previously made account
        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emaill = emailAddress.getText().toString();
                String passwordd = editTextPassword.getText().toString();
                if (emaill.isEmpty() || passwordd.length() < 6) {
                    Toast.makeText(LoginActivity.this, "Please fill all fields and ensure password is min 6 characters", Toast.LENGTH_LONG).show();
                } else {
                    Boolean checkCredentials = loginDatabase.checkUser(emaill, passwordd);
                    if (checkCredentials) {
                        Toast.makeText(LoginActivity.this, "User signed in", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid login", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

    }

}