package com.zybooks.fernandolomeliinventory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemAdapterVh> implements Filterable {

    public List<Item> itemList = new ArrayList<>();
    public List<Item> getItemListFilter = new ArrayList<>();
    public Context context;



    public ItemAdapter(List<Item> items, Context context){
        this.itemList = items;
        this.context = context;
        this.getItemListFilter = items;

    }

    @NonNull
    @Override
    public ItemAdapterVh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.custom_list, parent, false);
        return new ItemAdapterVh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemAdapterVh holder, int position) {

        Item item = itemList.get(position);
        String name = item.getName();
        String quantity = item.getQuantity();

        holder.itemName.setText(name);
        holder.itemQuantity.setText(quantity);

    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                if(charSequence == null || charSequence.length() == 0) {
                    filterResults.values = getItemListFilter;
                    filterResults.count = getItemListFilter.size();
                } else {
                    String searchText = charSequence.toString().toLowerCase();
                    List<Item> items = new ArrayList<>();
                    for (Item item: getItemListFilter) {
                        if(item.getName().toLowerCase().contains(searchText)) {
                            items.add(item);
                        }
                    }

                    filterResults.values = items;
                    filterResults.count = items.size();
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                itemList = (List<Item>) filterResults.values;
                notifyDataSetChanged();

            }
        };
        return filter;
    }

    public static class ItemAdapterVh extends RecyclerView.ViewHolder {

        private TextView itemName;
        private TextView itemQuantity;

        public ItemAdapterVh(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
        }
    }
}
