package com.zybooks.fernandolomeliinventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

// This activity was created to add items to the inventory list
public class AddItemActivity extends AppCompatActivity {

    //initialize fields
    List<Item> itemList = new ArrayList<>();

    EditText itemName, editTextQuantity;
    Button confirmButton, cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        itemName = findViewById(R.id.itemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        confirmButton = findViewById(R.id.confirmButton);
        cancelButton = findViewById(R.id.cancelButton);


        //Set the confirm button to add an item to the database/list
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = itemName.getText().toString();
                String quantity = editTextQuantity.getText().toString().trim();
                itemList.add(new Item(name, quantity));
            }
        });

        //Sets the cancel button to cancel this activity and head back to the Inventory Activity
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);
            }
        });

    }
}